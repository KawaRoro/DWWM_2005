const Employee = require ('./Models/Employee.js');
const f = require ('./functions.js');
const f2 = require ('./functions2.js');


var employe1 = new Employee();
var employe2 = new Employee();

let result = f(9,2);

let test = f2.a(3, 3);

console.log();