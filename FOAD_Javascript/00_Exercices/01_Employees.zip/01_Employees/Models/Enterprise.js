const Employee = require('./Employee.js');

/**
 * Gestion d'employés
 */
class Enterprise 
{
    constructor() {
        this.employees = [];
    }

    /**
     * 
     * @param  _filter 
     */
    readAll(_filter) {
        
    }

    /**
     * Créer un employé
     * @param Employee _employee 
     */
    create(_employee) {

    }

    /**
     * 
     * @param int _id 
     */
    read(_id) { 

    }

    /**
     * Met à jour un employé
     * @param Employee _employee 
     */
    update(_employee) {

    }
    
    /**
     * Supprime un employé
     * @param int _id 
     */
    delete(_id) {

    }


    /**
     * 
     */
    getHigherSalary() {

    }

    /**
     * 
     */
    getLowerSalary() {

    }

    /**
     * 
     */
    getSalaryGap() {

    }


    



}


module.exports = Enterprise;
