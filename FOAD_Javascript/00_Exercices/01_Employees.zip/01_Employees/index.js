const Employee = require ('./Models/Employee.js');


var employe1 = new Employee.Employee();

let role = Employee.RoleParDefaut;

console.log();