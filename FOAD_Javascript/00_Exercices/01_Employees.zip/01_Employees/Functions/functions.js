function myFunc(a, b) {
    return a + b;
}

module.exports = myFunc; // la fonction est exportée en tant que "module"